# CSS Model

A Pen created on CodePen.

Original URL: [https://codepen.io/lakshaya-selvam/pen/empGmyp](https://codepen.io/lakshaya-selvam/pen/empGmyp).

