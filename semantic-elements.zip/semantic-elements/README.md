# Semantic Elements

A Pen created on CodePen.

Original URL: [https://codepen.io/lakshaya-selvam/pen/MYavbmE](https://codepen.io/lakshaya-selvam/pen/MYavbmE).

